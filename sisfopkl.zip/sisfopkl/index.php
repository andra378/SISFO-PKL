<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>SISFO PKL SMKN 9 MEDAN</title>
    <style>
        body{
        font-family:Arial, Helvetica, sans-serif;
        padding: 0;
        margin: 0;
        background-color: white;
        }
        header,footer{
            background-color: #00aaff;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
        nav{
            background-color: #0077ac;
            padding: 10px;
            text-align: center;
        }
        nav a{
            color: white;
            margin: 0 15px;
            text-decoration: none;
        }
        nav a:hover{
            text-decoration: none;
        }
        #content{
            padding: 20px;
        }
        iframe{
            width: 100%;
            height: 400px;
            border: none;
        }
    </style>
</head>
<body>
    <?php include "header.php";?>
    <?php include "menu.php";?>
    <div id="content">
        <iframe name="contentFrame" src="crud?home.php"></iframe>
    </div>
    <?php include "footer.php";?>
</body>
</html>